import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
file_path = "../data/sample_weather.csv"
df = pd.read_csv(file_path)

# Data cleaning
df['Date'] = pd.to_datetime(df['Date'])
df['Temperature'] = pd.to_numeric(df['Temperature'], errors='coerce')
df.dropna(inplace=True)

# Line chart
plt.figure(figsize=(10,6))
sns.lineplot(x='Date', y='Temperature', data=df, marker='o')
plt.title("Daily Temperature Trends (30 Days)")
plt.xlabel("Date")
plt.ylabel("Temperature (°C)")
plt.grid(True)
plt.savefig("../output/temperature_trend.png")
plt.show()

# Bar chart
plt.figure(figsize=(10,6))
sns.barplot(x='Date', y='Temperature', data=df, color="skyblue")
plt.title("Daily Temperature (Bar Chart) - 30 Days")
plt.xlabel("Date")
plt.ylabel("Temperature (°C)")
plt.xticks(rotation=45)
plt.savefig("../output/temperature_bar.png")
plt.show()
